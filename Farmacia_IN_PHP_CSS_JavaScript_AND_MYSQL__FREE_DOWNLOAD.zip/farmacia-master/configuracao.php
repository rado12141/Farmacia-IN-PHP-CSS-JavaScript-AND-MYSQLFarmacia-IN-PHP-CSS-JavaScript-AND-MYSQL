<?php
echo 'configurações';