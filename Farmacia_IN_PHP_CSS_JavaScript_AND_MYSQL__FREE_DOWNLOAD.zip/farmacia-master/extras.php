<?php
?>
<div class="container-fluid">
    <div class="card" style="width: 700px;height: 360px;margin-left: 50px;margin-top: 30px;background-color:#faf2cc">
        <br/>
<h3 style="margin-top: 5px;margin-left: 8px">Extras</h3>
        <div class="row">

        <div class="col-md-2" style="margin-top: 100px;margin-left: 50px">
            <label>
              <a href="backup.php "><button  style="width: 65px;height: 43px"><i class="pe-7s-server"></i> </button></a>
                <p>BAKCUP</p></label>
        </div>

        <div class="col-md-2" style="margin-top: 100px">
            <label>
                    <a href="?pg=lembrete"><button  style="width: 65px;height: 43px"><i class="pe-7s-note"></i> </button></a>
                <p>LEMBRETE</p>
                </label>
        </div>

        </div>
    </div>
</div>
